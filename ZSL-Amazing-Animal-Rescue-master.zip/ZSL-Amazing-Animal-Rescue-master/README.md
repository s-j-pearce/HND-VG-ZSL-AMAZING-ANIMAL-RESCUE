# Design Documentation

## I. Introduction

In this game, the player(s) aim is to uncover facts and information that is hidden underneath a row of 'cards'. The player must move these cards and put them in order on a different row in order to reveal the hidden information. The game is being designed and made for ZSL and as such, the information included on and underneath the cards is to do with the greenhouse gas chain for 4 different products (Plastic bottles, Mobile Phones, Beef, and Electronics being left on standby) and the cards themselves are each step of the chain.

## II. Game Objective

The objective/purpose of this game is to teach children aged 11-16 about the steps that go in to making each of the 4 products, and raise awareness about how much greenhouse gas is produced. The game will also tell the player(s) how they can help to reduce the ammount of greenhouse gasses released.

## III. Genre

The game is a 2D, top down, educational puzzle solving game.

## VI. Features

- 2D Top Down
- Interactive
- Educational
- Web Based
- Tocuh Screen Support

## V. Platform

The game will be built as a web based app. This means that any device that has a compatable browser installed will be able to play the game. However, as requested by ZSL, the game will be optimised to run on iPad devices for use in their classes.

## Included Text

This section will detail what text is to be included in the game.

All the text shown here will be placed on the cards that the player has to drag and drop into the correct order. Each card will contain one step. The first and last steps of the chain will be already in place for the players to give them somewhere to begin.

### Beef (British Wildlife)
1. Carbon is released when tress are cut down to make space to grow cows feed
2. Carbon is released from pesticides that are used on cow feed to stop them being damaged
by pests
3. Carbon and nitrous oxide released from fertilisers that are used to grow the feed
4. Carbon released when electricity pumps water from rivers, streams etc to provide water for
the cows and their feed
5. Carbon released from farm vehicles and machinery that are used on farms
6. Methane released from cows when they past wind
7. Carbon released from when animals are transported to slaughter house
8. Carbon released as electricity powers all machinery and resources in farm
9. Carbon released when making the packing for the beef
10. Carbon released when beef is transported to shops and restaurants
11. Carbon released as electricity power machines and resources in shops and restaurants
12. Carbon released when customers travel to the shops and restaurants
13. Methane released as beef packaging decomposes in landfills.

### Plastic Bottles (Ocean)
1. Carbon released as drilling rigs are constructed and run
2. Carbon released as oil is transported to treatment plants
3. Carbon released as electricity is used to clean oil
4. Carbon released as oil is transported to manufactures
5. Carbon released when electricity is used to turn the oil into lids and plastic bottles
6. Carbon released as plastic bottles are transported to a bottling plant
7. Carbon released when machinery fills bottles with a drink
8. Carbon released when bottles are packaged
9. Carbon released as plastic bottles are transported to shops and restaurants
10. Carbon released as electricity powers machinery and resources in shops and restaurants
11. Carbon released as customers travel to the shops and restaurants
12. Methane released as plastic bottles decompose in landfills.

### Electronics left on standby (Arctic Tundra)
1. Carbon released when natural gas drilling rigs are constructed and run
2. Carbon released as natural gas is transported using pipes to treatment plants.
3. Carbon released is used to clean and dry the natural gas
4. Carbon released when natural gas is odorised so people can smell it when there is a gas leak
5. Carbon released as natural gas is transported via pipes to power stations in the UK
6. Carbon released when natural gas is burned in power stations to drive turbines to produce
electricity
7. Carbon released as electricity is needed for pylons /powerlines to carry electricity
8. 15kg of carbon waster per year leaving TV on standby.

### Mobile Phone (Rainforest)
1. Carbon released when as drilling rigs and mines are constructed and run to extract raw
materials which destroys the rainforest
2. Carbon released as raw materials are transported to factories around the world
3. Carbon released when electricity is generated to construct usable phone parts using the raw
materials
4. Caron released when mobile phones are packaged
5. Carbon released as constructed mobile phones are transported to shops
6. Carbon released as electricity powers machines and resources in the shops
7. Carbon released as customers travel to the shops
8. Carbon released when electricity is used every time the phone is charged
9. Carbon released as raw materials continue to be mined if the phone is not recycled
